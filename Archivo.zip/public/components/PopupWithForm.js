import { Popup } from "./Popup";
export class PopupWithForm extends Popup {
    constructor(selector, handleFormSubmit) {
        super(selector);
        this._formElement = this._popupElement.querySelector(".popup__form");
        this._handleFormSubmit = handleFormSubmit;
    }
    _getInputValues() {
        const inputs = Array.from(this._formElement.querySelectorAll(".popup__input"));
        const values = {};
        inputs.forEach((input) => {
            values[input.name] = input.value;
        });
        return values;
    }
    setEventListeners() {
        super.setEventListeners();
        this._formElement.addEventListener("submit", (evt) => {
            evt.preventDefault();
            this._handleFormSubmit(this._getInputValues());
        });
    }
    close() {
        super.close();
        this._formElement.reset();
    }
}
